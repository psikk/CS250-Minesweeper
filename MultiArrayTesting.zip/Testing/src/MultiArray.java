
public class MultiArray {
	private int dim;
	private static int[][] array;
	private static int[][] array2;
	public MultiArray() {
		// TODO Auto-generated constructor stub
	}
	
	


	/**
	 * @param dim: the dimensions of a square 2D array
	 * Method to construct an array containing 1s (mines) and 0s (empty)
	 */
	public MultiArray(int dim) {
		int total = (int) ((dim * dim) * 0.16);
		int count = 0;
		int loc = 0;
		//total += (int)(Math.random() * 4);
		int[][] twoD_arr = new int[dim][dim];
		/*
		 * fills in the matrix with 1s(mines) and 0s(empty) space
		 */
		for(int row = 0; row < dim; row++) {
			for(int col = 0; col < dim; col++) {
				double prob = Math.random();
				if(prob <= (((double) total - count)/((dim*dim) - loc))) {
				twoD_arr[row][col] = 1;
				count++;
				} else {
					twoD_arr[row][col] = 0;	
				}
				loc++;
			}}
		this.array = twoD_arr;
		}
	/*
	 * Prints the input array as text to the console
	 * input: array: the array that will be displayed to the console
	 */
	public static void printField(int[][] array) {
		for(int row = 0; row < array.length; row++) {
			for(int col = 0; col < array.length; col++) {
				System.out.print(array[row][col] + "\t");
			}
			System.out.println();
		}
	}
	
	/*
	 * Counts the number of mines in an array and prints the value to the console
	 * input: array: the array in which the mines will be counted
	 */
	public static void countMines(int[][] array) {
		int value = 0;
		for(int row = 0; row < array.length; row++) {
			for(int col = 0; col < array.length; col++) {
				value += array[row][col];
			}
		}
		System.out.println();
		System.out.print("The total number of Mines: " + value);
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		MultiArray mine = new MultiArray(10);
		printField(array);
		countMines(array);
		fieldCount(array);
		System.out.println();
		System.out.println("------------");
		printField(array2);
	}
	
	//this method counts how many mines are in the surrounding spaces in the mine field
	public static void fieldCount(int[][] array) {
		//create new 2d array to store new values
		int[][] fieldCount = new int[array.length][array.length];
		//initialize int to store sum before added to array
		int surroundCounts;
		//runs code for each row-column pair
		for(int row = 0; row < array.length; row++) {
			for(int col = 0; col < array.length; col++) {
				//if cell contains a mine, no need to find surrounding mines since clicking would end game
				if(array[row][col] == 1)
					surroundCounts = -1;
				//if top row and neither corner
				else if(row == 0 && (col != 0 && col != array.length-1))
					surroundCounts = array[row][col-1] + array[row +1][col-1] + array[row + 1][col] + array[row][col+1] +array[row +1][col+1];
				//if top left corner
				else if(row == 0 && col == 0)
					surroundCounts = array[row + 1][col] + array[row][col+1] +array[row +1][col+1];
				//if top right corner
				else if(row == 0 && col == array.length-1)
					surroundCounts = array[row][col-1] + array[row +1][col-1] + array[row + 1][col];
				//if left edge and neither corner
				else if((row != 0 && row != array.length-1) && col == 0)
					surroundCounts = array[row -1][col] + array[row + 1][col] + array[row -1][col+1] + array[row][col+1] +array[row +1][col+1];
				//if neither corner nor edge
				else if((row != 0 && row != array.length-1)&&(col != 0 && col != array.length-1))
					surroundCounts = array[row -1][col-1] + array[row][col-1] + array[row +1][col-1] + array[row -1][col] + array[row + 1][col] + array[row -1][col+1] + array[row][col+1] +array[row +1][col+1];
				//if right edge and neither corner
				else if((row != 0 && row != array.length-1)&& col == array.length-1)
					surroundCounts = array[row -1][col-1] + array[row][col-1] + array[row +1][col-1] + array[row -1][col] + array[row + 1][col];
				//if bottom left corner
				else if(row == array.length-1 && col == 0)
					surroundCounts = array[row -1][col] + array[row -1][col+1] + array[row][col+1];
				//if bottom row and neither corner
				else if(row == array.length-1 && (col != 0 && col != array.length-1))
					surroundCounts = array[row -1][col-1] + array[row][col-1] + array[row -1][col] + array[row -1][col+1] + array[row][col+1];
				//if bottom right corner
				else
					surroundCounts = array[row -1][col-1] + array[row][col-1] + array[row -1][col];
				//store to field count array with the corresponding index
				fieldCount[row][col] = surroundCounts; 
				//store field counts array to the array2 location to be called later
				array2 = fieldCount;
				
			}
			}
				
				
		}
			
	}


